package com.example.Getrequest;

public class Person {
    String name;
    String email;
    String password;
    String retypepassword;
    Long phonenumb;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRetypepassword() {
        return retypepassword;
    }

    public void setRetypepassword(String retypepassword) {
        this.retypepassword = retypepassword;
    }

  public Long getPhonenumb() {
        return phonenumb;
    }

    public void setPhonenumb(Long phonenumb) {
        this.phonenumb = phonenumb;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    @Override
    public String toString(){
        return Person(name="+ name+",email=" +email+",password=" +password+",retypepassword=" +retypepassword+",phonenumb=" +phonenumb+");
    }

}