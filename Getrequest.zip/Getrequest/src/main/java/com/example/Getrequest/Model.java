package com.example.Getrequest;

import java.util.Scanner;

public class Model {

    public static void signup() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter name:");
        String name = sc.nextLine();
        System.out.println("Enter email:");
        String mail = sc.nextLine();
        System.out.println("Enter phonenumb:");
        Long phonenum = sc.nextLong();
        System.out.println("Enter password:");
        String password = sc.nextLine();
        System.out.println("Enter retypepassword:");
        String retypepassword = sc.nextLine();
        System.out.println("you have signup successfully");
    }

    public static void login() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter phonenumb:");
        Long phonenum = sc.nextLong();
        System.out.println("Person password: ");
        String mail = sc.nextLine();
        System.out.println("This is your main page");
    }
}
