package com.example.Getrequest;

import org.springframework.beans.factory.annotation.Autowired;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

@org.springframework.stereotype.Repository

public class Repository {
    @Autowired
    Connection con;
    Statement stm = null;
    @Autowired
    JdbcTemplate jdbcTemplate;
    person detail = new person();

    public void insertNewPersonToDatabase() {
        String sql = "INSERT INTO person(string username,string password,String email,String retypepassword) VALUES(?,?,?,?)";
        Object params[] = new Object[]{name,email,password,retypepassword};
        jdbcTemplate.update(sql, params);
    }

    public void getPerson(Long phonenumb) {
        String sql = "SELECT * FROM friend WHERE id = ?";
        Object params[] = new Object[]{phonenumb};
        return jdbcTemplate.queryForObject(sql, params, BeanPropertyRowMapper.newInstance(Person.class));
    }

    public person readdata(String name) throws SQLException {
        String sqls = "select*from person where username='" + name + "'";
        ResultSet res = stm.executeQuery(sql);
        while (res.next()) {
            person.setusername(res.getString(1));
            person.setmail(res.getString(2));
            person.setpassword(res.getString(3));
            person.retypepassword(res.getString(4));
            System.out.println(res.getString(1));
        }
    }
}



