package com.example.Getrequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.*;

@RestController
public class Controller {
    @Autowired
    Repository repository;
    @Autowired
    Person Detail;

    @GetMapping(value = "/signup")
    public String hello(@RequestParam(value = "name") String name, @RequestParam(value = "email") String email,
                        @RequestParam(value = "password") String password,@RequestParam(value = "retypepassword") String retypepassword,@RequestParam(value = "phonenumb") int phonenumb) {
        repository.insertNewPersonToDatabase(name, email, password, retypepassword, phonenumb);

    @PostMapping("/login")
        String username=username;
        String password=password;

            if((username ==username) {
                if((password==password) {
                    System.out.println("succeesfully logged in");
                    return;
                }else{
                    System.out.println("The username and password does not match");
                    return;
                }
            }
        System.out.println("\"The username doesnot exist ! plesase enter correct usn and pwd");
    }
     @GetMapping(value = "/signupp")
         String username;
         String  password;
         String repeatpassword;
        if(password==repeatpassword){
            System.out.println("successfully signed up");
        }else{
            System.out.println("The password not match and try agin");
        }


    @Bean
    public Person employeeDetails(@RequestBody PersonDetail personDetail){
            repository.insertNewPersonToDatabase();
            return personDetails;


        }