package com.example.Getrequest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Config {
    @Value("${spring.datasource.url}")
    String url;
    @Value("${spring.datasource.username}")
    String username;
    @Value("${spring.datasource.password}")
    String password;

    @Bean
    public Model modelObj(){
        return new Model();
    }
    @Bean
    public Connection connection() throws SQLException {
        Connection con= DriverManager.getConnection(url,username,password);
        return con;
    }
}

